import os 

cmnd = "python app_exe.py node[0].txt processed/node[0].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[1].txt processed/node[1].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[2].txt processed/node[2].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[3].txt processed/node[3].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[4].txt processed/node[4].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[5].txt processed/node[5].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[6].txt processed/node[6].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[7].txt processed/node[7].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[8].txt processed/node[8].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[9].txt processed/node[9].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[10].txt processed/node[10].txt"
os.system(cmnd)
cmnd = "python app_exe.py node[11].txt processed/node[11].txt"
os.system(cmnd)
