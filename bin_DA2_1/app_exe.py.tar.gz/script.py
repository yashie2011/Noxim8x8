import os 

cmnd = "python node[1].txt processed/node[1].txt"
os.system
cmnd = "python node[2].txt processed/node[2].txt"
cmnd = "python node[3].txt processed/node[3].txt"
cmnd = "python node[4].txt processed/node[4].txt"
cmnd = "python node[5].txt processed/node[5].txt"
cmnd = "python node[6].txt processed/node[6].txt"
cmnd = "python node[7].txt processed/node[7].txt"
cmnd = "python node[8].txt processed/node[8].txt"
cmnd = "python node[9].txt processed/node[9].txt"
cmnd = "python node[10].txt processed/node[10].txt"
cmnd = "python node[11].txt processed/node[11].txt"
